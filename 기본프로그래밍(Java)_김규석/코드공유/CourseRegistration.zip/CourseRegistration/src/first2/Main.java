package first2;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Menu menu = new Menu();
		while(true) {
			int m = menu.printMainMenu();
			if (m == 1) {
				menu.printCourseList();
			}
		}
	}
}
