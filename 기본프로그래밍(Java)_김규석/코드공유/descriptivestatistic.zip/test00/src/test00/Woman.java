package test00;

public class Woman extends People {
	public void printContent() {
		System.out.println("Woman");
	}
}
