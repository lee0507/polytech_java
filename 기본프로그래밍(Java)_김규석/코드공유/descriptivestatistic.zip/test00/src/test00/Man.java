package test00;

public class Man extends People {
	public void printContent() {
		System.out.println("Man");
	}
}
