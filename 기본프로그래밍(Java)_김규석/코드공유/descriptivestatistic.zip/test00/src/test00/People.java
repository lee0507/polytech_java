package test00;

public class People {
	public void printContent() {
		System.out.println("People");
	}
}
